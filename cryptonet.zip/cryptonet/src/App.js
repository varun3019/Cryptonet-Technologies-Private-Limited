import logo from './logo.svg';
import './App.css';
import { useEffect,useState } from 'react';

function App() {
  const [userdata,setuserdata]=useState([])

  useEffect( ()=> {
    let fetchdata = async ()=>
  {
    let data=await fetch("https://randomuser.me/api/?page=1&results=1&seed=abc");
    let datajson = await data.json();
    setuserdata(datajson)
  }
  fetchdata()
},[])

  return (
    <div className="flex justify-center items-center m-10">
    {userdata.results && userdata.results.map((user, index) => (
      <div key={index} className="w-80 md:w-96 bg-gray-200 bg-opacity-50 rounded-lg p-6 ">
        <img src={user.picture.large} className="w-full rounded-md mb-4 " alt="User Avatar"/>
        <p className="font-mono text-lg text-gray-800 mb-2 text-center italic ...">{user.name.title} {user.name.first} {user.name.last}</p>
        <p className="font-mono text-lg text-gray-800 mb-2  text-center italic ...">{user.gender}</p>
        <p className="font-mono text-lg text-gray-800 mb-2 text-center italic ...">{user.location.street.number} {user.location.street.name}</p>
        <p className="font-mono text-lg text-gray-800 mb-2 text-center italic ...">{user.location.city}, {user.location.state}, {user.location.country}, {user.location.postcode}</p>
        <p className="font-mono text-lg text-gray-800 mb-2 text-center italic ...">{user.email}</p>
        <p className="font-mono text-lg text-gray-800 mb-2 text-center italic ...">{user.dob.date} {user.dob.age}</p>
        <p className="font-mono text-lg text-gray-800 mb-2 text-center italic ...">{user.phone} {user.cell}</p>
      </div>
    ))}
  </div>
  
  );
}

export default App;
